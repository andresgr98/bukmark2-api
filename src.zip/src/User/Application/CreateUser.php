<?php

use App\Entity\User;

class CreateUser {

    public function __construct(private readonly UserRepository $userRepository)
    { }
    public function create(
        string $email, 
        string $password, 
        string $firstName, 
        string $lastName
    ): User {
        $user = new User();
        $user->setEmail($email);
        $user->setPassword($password);
        $user->setFirstName($firstName);
        $user->setLastName($lastName);
        $this->userRepository->save($user);
        return $user;
    }
}
